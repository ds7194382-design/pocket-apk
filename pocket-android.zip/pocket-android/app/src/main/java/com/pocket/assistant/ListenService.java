package com.pocket.assistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Keeps listening in the background for "Hey Pocket", then runs the command that follows. */
public class ListenService extends Service {

    public static final String ACTION_STOP = "com.pocket.assistant.STOP";
    public static final String ACTION_RELOAD = "com.pocket.assistant.RELOAD";
    public static final String ACTION_CMD = "com.pocket.assistant.CMD";
    public static final String ACTION_LOG = "com.pocket.assistant.LOG";
    public static final String ACTION_SAY = "com.pocket.assistant.SAY";
    public static final String EXTRA_TEXT = "text";

    static volatile boolean running = false;

    private static final String CHANNEL = "pocket_listen";
    private static final int NOTE_ID = 77;
    private static final Pattern WAKE = Pattern.compile("(pocket|पॉकेट|पोकेट)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern FEMALE = Pattern.compile(
            "female|-hia-|-hic-|-ena-|-enc-|-ene-|-iob-|-iog-|-sfg-|-tpc-|-tpf-", Pattern.CASE_INSENSITIVE);

    private final Handler h = new Handler(Looper.getMainLooper());
    private SpeechRecognizer sr;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean speaking = false;
    private boolean stopped = false;
    private long awaitUntil = 0;
    private int utter = 0;

    private final Runnable startRunnable = new Runnable() {
        @Override
        public void run() {
            startListening();
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                ttsReady = status == TextToSpeech.SUCCESS;
                if (ttsReady) {
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override
                        public void onStart(String id) {}

                        @Override
                        public void onDone(String id) {
                            doneSpeaking();
                        }

                        @Override
                        public void onError(String id) {
                            doneSpeaking();
                        }
                    });
                }
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            startAsForeground();
        } catch (Exception e) {
            log("Could not start in the background: " + e.getMessage());
            stopSelf();
            return START_NOT_STICKY;
        }
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_CMD.equals(action)) {
            String text = intent.getStringExtra(EXTRA_TEXT);
            if (text != null && !text.trim().isEmpty()) runCommand(text.trim());
            return START_STICKY;
        }
        if (ACTION_SAY.equals(action)) {
            String say = intent.getStringExtra(EXTRA_TEXT);
            if (say != null && !say.trim().isEmpty()) {
                log("Pocket: " + say);
                speak(say, "neutral");
            }
            return START_STICKY;
        }
        if (ACTION_RELOAD.equals(action)) {
            destroyRecognizer();
        }
        h.removeCallbacks(startRunnable);
        h.postDelayed(startRunnable, 400);
        return START_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Pocket listening", NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(ch);

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, ListenService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Pocket is listening")
                .setContentText("Say \"Hey Pocket\"")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(openPi)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause, "Stop", stopPi).build())
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(NOTE_ID, n);
        }
    }

    private String lang() {
        SharedPreferences p = getSharedPreferences("pocket", MODE_PRIVATE);
        return p.getString("lang", "en-IN");
    }

    private void startListening() {
        if (stopped || speaking) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            log("Speech recognition is not available on this phone.");
            return;
        }
        try {
            if (sr == null) {
                sr = SpeechRecognizer.createSpeechRecognizer(this);
                sr.setRecognitionListener(listener);
            }
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang());
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
            sr.startListening(i);
        } catch (Exception e) {
            log("Microphone error: " + e.getMessage());
            destroyRecognizer();
            schedule(2000);
        }
    }

    private void schedule(long ms) {
        if (stopped) return;
        h.removeCallbacks(startRunnable);
        h.postDelayed(startRunnable, ms);
    }

    private void destroyRecognizer() {
        if (sr != null) {
            try {
                sr.cancel();
                sr.destroy();
            } catch (Exception ignored) {
            }
            sr = null;
        }
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override
        public void onReadyForSpeech(Bundle params) {}

        @Override
        public void onBeginningOfSpeech() {}

        @Override
        public void onRmsChanged(float rmsdB) {}

        @Override
        public void onBufferReceived(byte[] buffer) {}

        @Override
        public void onEndOfSpeech() {}

        @Override
        public void onPartialResults(Bundle partialResults) {}

        @Override
        public void onEvent(int eventType, Bundle params) {}

        @Override
        public void onError(int error) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                log("Microphone permission is missing. Open the app and allow it.");
                stopSelf();
                return;
            }
            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                destroyRecognizer();
                schedule(1500);
                return;
            }
            if (error == SpeechRecognizer.ERROR_CLIENT) {
                destroyRecognizer();
            }
            schedule(500);
        }

        @Override
        public void onResults(Bundle results) {
            ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (list != null && !list.isEmpty()) heard(list);
            if (!speaking) schedule(300);
        }
    };

    private void heard(ArrayList<String> list) {
        long now = System.currentTimeMillis();
        if (now < awaitUntil) {
            awaitUntil = 0;
            runCommand(list.get(0));
            return;
        }
        for (String s : list) {
            Matcher m = WAKE.matcher(s);
            if (m.find()) {
                String rest = s.substring(m.end()).trim();
                if (rest.length() > 1) {
                    runCommand(rest);
                } else {
                    awaitUntil = now + 9000;
                    boolean hi = lang().startsWith("hi");
                    speak(hi ? "हाँ, बोलिए?" : "Yes? I am listening.", "happy");
                }
                return;
            }
        }
    }

    private void runCommand(String text) {
        log("You: " + text);
        Commands.Result res = Commands.run(this, text);
        log("Pocket: " + res.text);
        speak(res.text, res.emotion);
        if (res.stop) {
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    stopSelf();
                }
            }, 3500);
        }
    }

    private static boolean isDeva(String s) {
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= 0x0900 && ch <= 0x097F) return true;
        }
        return false;
    }

    private void speak(String text, String emotion) {
        if (!ttsReady) return;
        speaking = true;
        try {
            if (sr != null) sr.cancel();
        } catch (Exception ignored) {
        }
        float pitch = 1.1f, rate = 1.0f, vol = 1.0f;
        switch (emotion == null ? "neutral" : emotion) {
            case "happy": pitch = 1.25f; rate = 1.05f; break;
            case "excited": pitch = 1.45f; rate = 1.2f; break;
            case "sad": pitch = 0.85f; rate = 0.8f; vol = 0.8f; break;
            case "calm": pitch = 1.0f; rate = 0.88f; vol = 0.85f; break;
            case "angry": pitch = 0.95f; rate = 1.2f; break;
            case "surprised": pitch = 1.6f; rate = 1.1f; break;
            case "whisper": pitch = 1.1f; rate = 0.8f; vol = 0.3f; break;
            case "loving": pitch = 1.2f; rate = 0.86f; vol = 0.9f; break;
            case "worried": pitch = 1.15f; rate = 1.05f; vol = 0.9f; break;
            default: break;
        }
        try {
            Locale loc = isDeva(text) ? new Locale("hi", "IN") : new Locale("en", "IN");
            tts.setLanguage(loc);
            Voice best = null;
            for (Voice v : tts.getVoices()) {
                if (v.getLocale().getLanguage().equals(loc.getLanguage()) && FEMALE.matcher(v.getName()).find()) {
                    best = v;
                    break;
                }
            }
            if (best != null) tts.setVoice(best);
            tts.setPitch(pitch);
            tts.setSpeechRate(rate);
            Bundle b = new Bundle();
            b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, vol);
            utter++;
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, b, "u" + utter);
        } catch (Exception e) {
            doneSpeaking();
        }
    }

    private void doneSpeaking() {
        h.post(new Runnable() {
            @Override
            public void run() {
                speaking = false;
                schedule(300);
            }
        });
    }

    private void log(String text) {
        Intent i = new Intent(ACTION_LOG).setPackage(getPackageName()).putExtra(EXTRA_TEXT, text);
        sendBroadcast(i);
    }

    @Override
    public void onDestroy() {
        stopped = true;
        running = false;
        h.removeCallbacksAndMessages(null);
        destroyRecognizer();
        if (tts != null) {
            try {
                tts.stop();
                tts.shutdown();
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
