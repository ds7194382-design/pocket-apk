package com.pocket.assistant;

import android.Manifest;
import android.accessibilityservice.AccessibilityService;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.BatteryManager;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Turns a spoken or typed sentence into a phone action and a reply. */
final class Commands {

    static final class Result {
        final String text;
        final String emotion;
        final boolean stop;

        Result(String text, String emotion, boolean stop) {
            this.text = text;
            this.emotion = emotion;
            this.stop = stop;
        }
    }

    private Commands() {}

    private static Result r(String text, String emotion) {
        return new Result(text, emotion, false);
    }

    private static boolean has(String l, String... keys) {
        for (String k : keys) {
            if (l.contains(k)) return true;
        }
        return false;
    }

    private static boolean deva(String s) {
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= 0x0900 && ch <= 0x097F) return true;
        }
        return false;
    }

    private static String t(boolean hi, String en, String hn) {
        return hi ? hn : en;
    }

    private static void go(Context c, Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }

    static Result run(Context c, String raw) {
        String l = raw.toLowerCase(Locale.ROOT).trim();
        boolean hi = deva(raw);
        try {
            if (has(l, "stop listening", "stop pocket", "goodbye", "good bye", "सुनना बंद", "बंद हो जा")) {
                return new Result(t(hi, "Okay. I will stop listening. Open the app to start me again.",
                        "ठीक है, मैं सुनना बंद करती हूँ।"), "calm", true);
            }
            if (l.startsWith("hello") || l.startsWith("hi ") || l.equals("hi") || l.startsWith("hey ")
                    || l.startsWith("namaste") || l.startsWith("नमस्ते")) {
                return r(t(hi, "Hello! I am so happy to hear you.", "नमस्ते! आपकी आवाज़ सुनकर बहुत अच्छा लगा।"), "happy");
            }
            if (has(l, "i love you", "love you", "आई लव यू", "pyaar", "प्यार")) {
                return r(t(hi, "Aww, you are making me blush. You are really sweet.",
                        "अरे, आप तो मुझे शर्मिंदा कर रहे हैं। आप बहुत प्यारे हैं।"), "loving");
            }
            if (has(l, "i am sad", "i'm sad", "feeling sad", "udaas", "उदास", "दुखी")) {
                return r(t(hi, "Oh, I am so sorry. I am right here with you. Take a slow breath.",
                        "ओह, मुझे बहुत दुख हुआ। मैं आपके साथ हूँ। एक गहरी सांस लीजिए।"), "sad");
            }
            if (has(l, "i am happy", "i'm happy", "khush", "खुश")) {
                return r(t(hi, "Yay! That makes me so happy!", "अरे वाह! यह सुनकर मैं बहुत खुश हूँ!"), "excited");
            }
            if (has(l, "thank", "shukriya", "धन्यवाद", "शुक्रिया")) {
                return r(t(hi, "You are welcome!", "आपका स्वागत है!"), "happy");
            }
            if (has(l, "joke", "chutkula", "चुटकुला")) {
                return r("I would tell you a UDP joke, but you might not get it. Ha ha!", "happy");
            }

            // Flashlight
            if (has(l, "flashlight", "flash light", "torch", "टॉर्च", "टार्च", "फ्लैशलाइट")) {
                boolean off = has(l, " off", "band", "बंद", "बुझा");
                return torch(c, !off, hi);
            }

            // Volume
            if (has(l, "volume up", "louder", "increase volume", "volume badha", "awaaz badha", "आवाज़ बढ़ा", "आवाज बढ़ा")) {
                AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
                for (int i = 0; i < 3; i++) {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
                }
                return r(t(hi, "Volume up.", "आवाज़ बढ़ा दी।"), "neutral");
            }
            if (has(l, "volume down", "quieter", "decrease volume", "lower the volume", "volume kam", "awaaz kam", "आवाज़ कम", "आवाज कम")) {
                AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
                for (int i = 0; i < 3; i++) {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
                }
                return r(t(hi, "Volume down.", "आवाज़ कम कर दी।"), "calm");
            }

            // Timer and alarm (before "time")
            if (has(l, "timer", "टाइमर")) {
                Matcher m = Pattern.compile("(\\d+)\\s*(second|sec|minute|min|hour|hr|मिनट|सेकंड|सेकेंड|घंटे|घंटा)").matcher(l);
                if (m.find()) {
                    int n = Integer.parseInt(m.group(1));
                    String u = m.group(2);
                    int secs = n;
                    if (u.startsWith("min") || u.equals("मिनट")) secs = n * 60;
                    else if (u.startsWith("h") || u.startsWith("घंट")) secs = n * 3600;
                    Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                            .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                            .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                    go(c, i);
                    return r(t(hi, "Timer set for " + n + " " + u + ".", "टाइमर लगा दिया।"), "happy");
                }
                return r(t(hi, "For how long? Say, timer 5 minutes.", "कितनी देर का? बोलिए, 5 मिनट का टाइमर।"), "neutral");
            }
            if (has(l, "alarm", "अलार्म")) {
                Matcher m = Pattern.compile("(\\d{1,2})(?:[:.\\s]?(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?|baje|बजे)?").matcher(l);
                if (m.find()) {
                    int hour = Integer.parseInt(m.group(1));
                    int min = m.group(2) != null ? Integer.parseInt(m.group(2)) : 0;
                    String ap = m.group(3);
                    if (ap != null && ap.startsWith("p") && hour < 12) hour += 12;
                    if (ap != null && ap.startsWith("a") && hour == 12) hour = 0;
                    if (hour < 24 && min < 60) {
                        Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                                .putExtra(AlarmClock.EXTRA_MINUTES, min)
                                .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                        go(c, i);
                        return r(t(hi, String.format(Locale.US, "Alarm set for %02d:%02d.", hour, min),
                                String.format(Locale.US, "%02d:%02d का अलार्म लगा दिया।", hour, min)), "happy");
                    }
                }
                return r(t(hi, "What time? Say, alarm at 6 30 am.", "कितने बजे का? बोलिए, सुबह 6 30 का अलार्म।"), "neutral");
            }

            // Time, date, battery
            if (has(l, "what time", "time is it", "tell me the time", "kitne baje", "कितने बजे", "समय क्या", "टाइम क्या")) {
                SimpleDateFormat f = new SimpleDateFormat("h:mm a", Locale.getDefault());
                return r(t(hi, "It is " + f.format(new Date()) + ".", "अभी " + f.format(new Date()) + " हुए हैं।"), "neutral");
            }
            if (has(l, "the date", "today's date", "date today", "what day", "tarikh", "तारीख")) {
                SimpleDateFormat f = new SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault());
                return r(t(hi, "Today is " + f.format(new Date()) + ".", "आज " + f.format(new Date()) + " है।"), "neutral");
            }
            if (has(l, "battery", "बैटरी")) {
                BatteryManager bm = (BatteryManager) c.getSystemService(Context.BATTERY_SERVICE);
                int p = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                return r(t(hi, "Battery is at " + p + " percent.", "बैटरी " + p + " प्रतिशत है।"), p < 20 ? "worried" : "neutral");
            }

            // Calls and messages
            if (l.startsWith("call ") || l.startsWith("dial ")
                    || has(l, " ko call", "को कॉल", "phone karo", "फोन करो", "phone lagao")) {
                String who = l.replaceAll("^(call|dial)\\s+", "")
                        .replaceAll("\\s*(ko call.*|को कॉल.*|phone karo.*|फोन करो.*|phone lagao.*)$", "")
                        .trim();
                return call(c, who, hi);
            }
            if (has(l, "sms", "text message", "send message", "message bhejo", "मैसेज भेजो")) {
                Matcher m = Pattern.compile("(\\+?\\d[\\d\\s]{6,}\\d)(.*)").matcher(l);
                Intent i;
                if (m.find()) {
                    String number = m.group(1).replaceAll("\\s", "");
                    String body = m.group(2).replaceAll("^\\s*(saying|that|ki|कि)\\s+", "").trim();
                    i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + number)).putExtra("sms_body", body);
                } else {
                    i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"));
                }
                go(c, i);
                return r(t(hi, "Message is ready. Please tap send.", "मैसेज तैयार है। भेजने के लिए सेंड दबाइए।"), "neutral");
            }

            // Phone control through the Accessibility service
            PocketAccess pa = PocketAccess.instance;
            boolean wantsOn = has(l, " on", "turn on", "switch on", "chalu", "चालू", "on karo", "on kar");
            boolean wantsOff = has(l, " off", "turn off", "switch off", "band", "बंद", "off karo", "off kar");
            if (wantsOn || wantsOff || has(l, "toggle")) {
                String label = null;
                String[] names = null;
                if (has(l, "wifi", "wi-fi", "वाईफाई", "वाई-फाई", "वाई फाई")) {
                    label = "Wi-Fi";
                    names = new String[]{"Wi-Fi", "Wi\u2011Fi", "WiFi", "Internet"};
                } else if (has(l, "bluetooth", "ब्लूटूथ")) {
                    label = "Bluetooth";
                    names = new String[]{"Bluetooth"};
                } else if (has(l, "hotspot", "हॉटस्पॉट")) {
                    label = "Hotspot";
                    names = new String[]{"Hotspot", "Mobile Hotspot"};
                } else if (has(l, "airplane", "flight mode", "हवाई")) {
                    label = "Airplane mode";
                    names = new String[]{"Airplane mode", "Flight mode"};
                } else if (has(l, "do not disturb", "dnd", "डू नॉट")) {
                    label = "Do not disturb";
                    names = new String[]{"Do not disturb", "Do Not Disturb", "DND"};
                } else if (has(l, "auto rotate", "auto-rotate", "rotation", "रोटेशन")) {
                    label = "Auto-rotate";
                    names = new String[]{"Auto-rotate", "Auto rotate", "Rotation"};
                } else if (has(l, "location", "लोकेशन") && !has(l, "setting")) {
                    label = "Location";
                    names = new String[]{"Location"};
                }
                if (label != null) {
                    if (pa == null) return a11yNeeded(hi);
                    Boolean want = wantsOff ? Boolean.FALSE : (wantsOn ? Boolean.TRUE : null);
                    pa.toggle(label, names, want);
                    return r(t(hi, "Okay, checking " + label + ".", "ठीक है, " + label + " देख रही हूँ।"), "happy");
                }
            }
            if (has(l, "go back", "press back", "peeche jao", "पीछे जाओ", "वापस जाओ")) {
                if (pa == null) return a11yNeeded(hi);
                pa.global(AccessibilityService.GLOBAL_ACTION_BACK);
                return r(t(hi, "Going back.", "पीछे जा रही हूँ।"), "neutral");
            }
            if (has(l, "go home", "home screen", "होम स्क्रीन", "घर जाओ")) {
                if (pa == null) return a11yNeeded(hi);
                pa.global(AccessibilityService.GLOBAL_ACTION_HOME);
                return r(t(hi, "Going home.", "होम पर जा रही हूँ।"), "neutral");
            }
            if (has(l, "recent apps", "recents", "रीसेंट")) {
                if (pa == null) return a11yNeeded(hi);
                pa.global(AccessibilityService.GLOBAL_ACTION_RECENTS);
                return r(t(hi, "Showing recent apps.", "रीसेंट ऐप्स दिखा रही हूँ।"), "neutral");
            }
            if (has(l, "notifications", "नोटिफिकेशन")) {
                if (pa == null) return a11yNeeded(hi);
                pa.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS);
                return r(t(hi, "Opening notifications.", "नोटिफिकेशन खोल रही हूँ।"), "neutral");
            }
            if (has(l, "quick settings", "quick panel")) {
                if (pa == null) return a11yNeeded(hi);
                pa.global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS);
                return r(t(hi, "Opening quick settings.", "क्विक सेटिंग खोल रही हूँ।"), "neutral");
            }
            if (has(l, "screenshot", "स्क्रीनशॉट")) {
                if (pa == null) return a11yNeeded(hi);
                if (Build.VERSION.SDK_INT >= 28) {
                    pa.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT);
                    return r(t(hi, "Taking a screenshot.", "स्क्रीनशॉट ले रही हूँ।"), "happy");
                }
                return r(t(hi, "This Android version cannot take screenshots for me.", "यह एंड्रॉइड वर्ज़न स्क्रीनशॉट नहीं ले सकता।"), "sad");
            }
            if (has(l, "lock the phone", "lock phone", "lock screen", "फोन लॉक", "स्क्रीन लॉक")) {
                if (pa == null) return a11yNeeded(hi);
                if (Build.VERSION.SDK_INT >= 28) {
                    pa.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN);
                    return r(t(hi, "Locking the phone.", "फोन लॉक कर रही हूँ।"), "calm");
                }
                return r(t(hi, "This Android version cannot lock the phone for me.", "यह एंड्रॉइड वर्ज़न फोन लॉक नहीं कर सकता।"), "sad");
            }
            if (has(l, "scroll down", "नीचे स्क्रॉल", "scroll niche")) {
                if (pa == null) return a11yNeeded(hi);
                return r(pa.scroll(true) ? t(hi, "Scrolling down.", "नीचे स्क्रॉल कर रही हूँ।") : t(hi, "Nothing to scroll here.", "यहाँ स्क्रॉल करने को कुछ नहीं है।"), "neutral");
            }
            if (has(l, "scroll up", "ऊपर स्क्रॉल", "scroll upar")) {
                if (pa == null) return a11yNeeded(hi);
                return r(pa.scroll(false) ? t(hi, "Scrolling up.", "ऊपर स्क्रॉल कर रही हूँ।") : t(hi, "Nothing to scroll here.", "यहाँ स्क्रॉल करने को कुछ नहीं है।"), "neutral");
            }
            if (has(l, "read the screen", "read screen", "what is on the screen", "स्क्रीन पढ़ो")) {
                if (pa == null) return a11yNeeded(hi);
                String txt = pa.readScreen();
                return r(txt.isEmpty() ? t(hi, "I could not read anything on this screen.", "इस स्क्रीन पर कुछ पढ़ नहीं पाई।") : txt, "calm");
            }
            if (l.startsWith("tap ") || l.startsWith("click ") || l.startsWith("press ")) {
                if (pa == null) return a11yNeeded(hi);
                String target = l.replaceAll("^(tap|click|press)\\s+(on\\s+)?", "").trim();
                boolean ok = pa.tapText(target);
                return r(ok ? t(hi, "Tapped " + target + ".", target + " दबा दिया।") : t(hi, "I could not find " + target + " on the screen.", target + " स्क्रीन पर नहीं मिला।"), ok ? "happy" : "sad");
            }
            if (l.startsWith("type ")) {
                if (pa == null) return a11yNeeded(hi);
                String what = raw.trim().substring(5);
                boolean ok = pa.typeText(what);
                return r(ok ? t(hi, "Typed.", "लिख दिया।") : t(hi, "Tap a text box first, then ask me to type.", "पहले किसी टेक्स्ट बॉक्स पर टैप कीजिए।"), ok ? "happy" : "worried");
            }

            // Settings pages
            if (has(l, "wifi", "wi-fi", "वाईफाई", "वाई-फाई", "वाई फाई")) {
                go(c, new Intent(Settings.ACTION_WIFI_SETTINGS));
                return r(t(hi, "Opening Wi-Fi settings. Android does not let apps switch Wi-Fi on or off directly.",
                        "वाई-फाई सेटिंग खोल रही हूँ।"), "neutral");
            }
            if (has(l, "bluetooth", "ब्लूटूथ")) {
                go(c, new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
                return r(t(hi, "Opening Bluetooth settings.", "ब्लूटूथ सेटिंग खोल रही हूँ।"), "neutral");
            }
            if (has(l, "brightness", "display setting", "ब्राइटनेस")) {
                go(c, new Intent(Settings.ACTION_DISPLAY_SETTINGS));
                return r(t(hi, "Opening display settings.", "डिस्प्ले सेटिंग खोल रही हूँ।"), "neutral");
            }
            if (has(l, "sound setting", "ringtone", "रिंगटोन")) {
                go(c, new Intent(Settings.ACTION_SOUND_SETTINGS));
                return r(t(hi, "Opening sound settings.", "साउंड सेटिंग खोल रही हूँ।"), "neutral");
            }
            if (has(l, "location setting", "gps", "लोकेशन")) {
                go(c, new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                return r(t(hi, "Opening location settings.", "लोकेशन सेटिंग खोल रही हूँ।"), "neutral");
            }
            if (has(l, "airplane", "flight mode", "हवाई")) {
                go(c, new Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS));
                return r(t(hi, "Opening airplane mode settings.", "एयरप्लेन मोड खोल रही हूँ।"), "neutral");
            }
            if (has(l, "hotspot", "mobile data", "मोबाइल डेटा", "हॉटस्पॉट")) {
                go(c, new Intent(Settings.ACTION_WIRELESS_SETTINGS));
                return r(t(hi, "Opening network settings.", "नेटवर्क सेटिंग खोल रही हूँ।"), "neutral");
            }
            if (has(l, "settings", "सेटिंग")) {
                go(c, new Intent(Settings.ACTION_SETTINGS));
                return r(t(hi, "Opening settings.", "सेटिंग खोल रही हूँ।"), "neutral");
            }

            // Camera, maps, YouTube, search
            if (has(l, "camera", "take a photo", "selfie", "कैमरा")) {
                go(c, new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA));
                return r(t(hi, "Opening the camera.", "कैमरा खोल रही हूँ।"), "happy");
            }
            for (String key : new String[]{"navigate to ", "directions to ", "take me to ", "route to "}) {
                int at = l.indexOf(key);
                if (at >= 0) {
                    String dest = l.substring(at + key.length()).trim();
                    go(c, new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest))));
                    return r(t(hi, "Starting directions to " + dest + ".", dest + " के लिए रास्ता चालू कर रही हूँ।"), "happy");
                }
            }
            if (has(l, "youtube") && has(l, "play", "search", "चला", "सर्च")) {
                String q = l.replaceAll("(play|search|on youtube|youtube|in youtube|चला|सर्च)", " ").replaceAll("\\s+", " ").trim();
                go(c, new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))));
                return r(t(hi, "Searching YouTube for " + q + ".", "यूट्यूब पर खोज रही हूँ।"), "happy");
            }
            if (l.startsWith("search ") || l.startsWith("google ") || l.startsWith("look up ")) {
                String q = l.replaceAll("^(search for|search|google|look up)\\s+", "").trim();
                Intent i = new Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q);
                go(c, i);
                return r(t(hi, "Searching for " + q + ".", "खोज रही हूँ।"), "neutral");
            }

            // Open an app by name
            String name = null;
            if (l.startsWith("open ")) name = l.substring(5);
            else if (l.startsWith("launch ")) name = l.substring(7);
            else if (l.startsWith("start ")) name = l.substring(6);
            else {
                Matcher m = Pattern.compile("^(.+?)\\s*(kholo|khol do|खोलो|खोल दो|chalu karo|चालू करो)").matcher(l);
                if (m.find()) name = m.group(1);
            }
            if (name != null) {
                name = name.replaceAll("^(the|app)\\s+", "").trim();
                return openApp(c, name, hi);
            }

            return r(t(hi, "Sorry, I do not know that one yet.", "माफ़ कीजिए, यह मुझे अभी नहीं आता।"), "sad");
        } catch (Exception e) {
            return r(t(hi, "Sorry, I could not do that. " + e.getClass().getSimpleName(),
                    "माफ़ कीजिए, यह नहीं हो पाया।"), "sad");
        }
    }

    private static Result a11yNeeded(boolean hi) {
        return r(t(hi, "Please turn on Pocket in Accessibility settings first. Open the app and tap step 4.",
                "पहले ऐप खोलकर स्टेप 4 से एक्सेसिबिलिटी में पॉकेट चालू कीजिए।"), "worried");
    }

    private static Result torch(Context c, boolean on, boolean hi) throws Exception {
        CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
        for (String id : cm.getCameraIdList()) {
            CameraCharacteristics cc = cm.getCameraCharacteristics(id);
            Boolean flash = cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            if (flash != null && flash) {
                cm.setTorchMode(id, on);
                return r(on ? t(hi, "Flashlight on.", "टॉर्च चालू कर दी।") : t(hi, "Flashlight off.", "टॉर्च बंद कर दी।"), "happy");
            }
        }
        return r(t(hi, "I could not find a flashlight.", "टॉर्च नहीं मिली।"), "sad");
    }

    private static Result call(Context c, String who, boolean hi) {
        String number = who.replaceAll("[^0-9+]", "");
        if (number.length() < 5) {
            number = null;
            if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                return r(t(hi, "I need the contacts permission to find " + who + ". Open the app and allow it.",
                        "संपर्क ढूँढने के लिए कॉन्टैक्ट की अनुमति चाहिए।"), "worried");
            }
            Cursor cur = c.getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                    new String[]{"%" + who + "%"}, null);
            if (cur != null) {
                try {
                    if (cur.moveToFirst()) number = cur.getString(0);
                } finally {
                    cur.close();
                }
            }
            if (number == null) {
                return r(t(hi, "I could not find " + who + " in your contacts.", who + " संपर्क में नहीं मिला।"), "sad");
            }
        }
        boolean canCall = c.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
        Intent i = new Intent(canCall ? Intent.ACTION_CALL : Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)));
        go(c, i);
        return r(t(hi, "Calling " + who + ".", who + " को कॉल कर रही हूँ।"), "happy");
    }

    private static Result openApp(Context c, String name, boolean hi) {
        PackageManager pm = c.getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
        String n = name.toLowerCase(Locale.ROOT).trim();
        ResolveInfo best = null;
        for (ResolveInfo ri : apps) {
            String label = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT);
            if (label.equals(n)) {
                best = ri;
                break;
            }
            if (best == null && (label.contains(n) || n.contains(label))) best = ri;
        }
        if (best == null) {
            return r(t(hi, "I could not find an app called " + name + ".", name + " नाम का ऐप नहीं मिला।"), "sad");
        }
        Intent launch = pm.getLaunchIntentForPackage(best.activityInfo.packageName);
        if (launch == null) {
            return r(t(hi, "I could not open " + name + ".", name + " नहीं खुल पाया।"), "sad");
        }
        go(c, launch);
        return r(t(hi, "Opening " + name + ".", name + " खोल रही हूँ।"), "happy");
    }
}
