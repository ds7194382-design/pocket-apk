package com.pocket.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends Activity {

    private static final int BG = 0xFF0E1512;
    private static final int SURFACE = 0xFF16201C;
    private static final int INK = 0xFFE6EEEA;
    private static final int MUTED = 0xFF8FA198;
    private static final int SIGNAL = 0xFF4FD6A3;

    private TextView status;
    private TextView logView;
    private Button toggle;
    private final StringBuilder logText = new StringBuilder();

    private final BroadcastReceiver logReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String t = intent.getStringExtra(ListenService.EXTRA_TEXT);
            if (t != null) appendLog(t);
        }
    };

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, primary ? 20 : 15);
        b.setTextColor(primary ? 0xFF06150F : INK);
        b.setBackgroundColor(primary ? SIGNAL : SURFACE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(primary ? 64 : 48));
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(36), dp(18), dp(28));
        scroll.addView(root);

        TextView title = text("Pocket Assistant", 30, INK);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        root.addView(title);
        TextView sub = text("Say \"Hey Pocket\" any time. Hindi and English.", 15, MUTED);
        root.addView(sub);

        status = text("", 15, SIGNAL);
        status.setPadding(0, dp(14), 0, dp(4));
        root.addView(status);

        toggle = button("Start Pocket", true);
        toggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ListenService.running) {
                    startService(new Intent(MainActivity.this, ListenService.class).setAction(ListenService.ACTION_STOP));
                    appendLog("Stopped.");
                    v.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            refresh();
                        }
                    }, 600);
                } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    askPermissions();
                } else {
                    startForegroundService(new Intent(MainActivity.this, ListenService.class));
                    appendLog("Started. Say Hey Pocket.");
                    v.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            refresh();
                        }
                    }, 600);
                }
            }
        });
        root.addView(toggle);

        root.addView(text("Set up once", 18, INK));
        ((TextView) root.getChildAt(root.getChildCount() - 1)).setPadding(0, dp(22), 0, 0);

        Button b1 = button("1. Allow microphone, notifications, contacts, calls", false);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askPermissions();
            }
        });
        root.addView(b1);

        Button b2 = button("2. Allow display over other apps (to open apps)", false);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            }
        });
        root.addView(b2);

        Button b3 = button("3. Battery: do not restrict Pocket", false);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        });
        root.addView(b3);

        Button b4 = button("4. Turn on Pocket in Accessibility (tap, scroll, Wi-Fi, Bluetooth)", false);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        root.addView(b4);

        LinearLayout langRow = new LinearLayout(this);
        langRow.setOrientation(LinearLayout.HORIZONTAL);
        Button en = button("English", false);
        Button hi = button("हिन्दी", false);
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(48), 1f);
        half.topMargin = dp(10);
        half.rightMargin = dp(5);
        en.setLayoutParams(half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        half2.topMargin = dp(10);
        half2.leftMargin = dp(5);
        hi.setLayoutParams(half2);
        en.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setLang("en-IN");
            }
        });
        hi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setLang("hi-IN");
            }
        });
        langRow.addView(en);
        langRow.addView(hi);
        root.addView(langRow);

        root.addView(text("Try a command", 18, INK));
        ((TextView) root.getChildAt(root.getChildCount() - 1)).setPadding(0, dp(22), 0, 0);

        final EditText input = new EditText(this);
        input.setHint("open WhatsApp, torch on, call mom, alarm 6 30 am");
        input.setHintTextColor(MUTED);
        input.setTextColor(INK);
        input.setSingleLine(true);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        root.addView(input);
        Button send = button("Send", false);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = input.getText().toString().trim();
                if (s.isEmpty()) return;
                if (!ListenService.running) {
                    appendLog("Tap Start Pocket first.");
                    return;
                }
                startService(new Intent(MainActivity.this, ListenService.class)
                        .setAction(ListenService.ACTION_CMD).putExtra(ListenService.EXTRA_TEXT, s));
                input.setText("");
            }
        });
        root.addView(send);

        logView = text("", 14, MUTED);
        logView.setPadding(0, dp(18), 0, 0);
        root.addView(logView);

        TextView note = text("Privacy: nothing is stored or sent to any server of ours. Android's own speech service turns your voice into text and may send audio to Google while the microphone is on.", 12, MUTED);
        note.setPadding(0, dp(24), 0, 0);
        root.addView(note);

        setContentView(scroll);
    }

    private void setLang(String code) {
        SharedPreferences p = getSharedPreferences("pocket", MODE_PRIVATE);
        p.edit().putString("lang", code).apply();
        appendLog("Language: " + code);
        if (ListenService.running) {
            startService(new Intent(this, ListenService.class).setAction(ListenService.ACTION_RELOAD));
        }
    }

    private void askPermissions() {
        ArrayList<String> need = new ArrayList<String>();
        need.add(Manifest.permission.RECORD_AUDIO);
        need.add(Manifest.permission.READ_CONTACTS);
        need.add(Manifest.permission.CALL_PHONE);
        if (Build.VERSION.SDK_INT >= 33) need.add("android.permission.POST_NOTIFICATIONS");
        requestPermissions(need.toArray(new String[0]), 1);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refresh();
    }

    private String mark(boolean ok, String label) {
        return (ok ? "[x] " : "[ ] ") + label;
    }

    private void refresh() {
        boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        boolean contacts = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED;
        boolean call = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
        boolean overlay = Settings.canDrawOverlays(this);
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean battery = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        status.setText((ListenService.running ? "Listening for Hey Pocket" : "Stopped") + "\n"
                + mark(mic, "Microphone") + "   " + mark(contacts, "Contacts") + "   " + mark(call, "Calls") + "\n"
                + mark(overlay, "Open apps from background") + "   " + mark(battery, "Battery unrestricted") + "\n"
                + mark(PocketAccess.instance != null, "Accessibility (phone control)"));
        toggle.setText(ListenService.running ? "Stop Pocket" : "Start Pocket");
    }

    private void appendLog(String line) {
        logText.append(line).append("\n");
        String s = logText.toString();
        String[] lines = s.split("\n");
        if (lines.length > 25) {
            StringBuilder sb = new StringBuilder();
            for (int i = lines.length - 25; i < lines.length; i++) sb.append(lines[i]).append("\n");
            logText.setLength(0);
            logText.append(sb);
        }
        logView.setText(logText.toString());
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter f = new IntentFilter(ListenService.ACTION_LOG);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(logReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(logReceiver, f);
        }
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(logReceiver);
        } catch (Exception ignored) {
        }
    }
}
