package com.pocket.assistant;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Lets Pocket press buttons, scroll, go back or home, and flip Quick Settings tiles
 * the same way you would with your finger. It only works after you switch it on in
 * Android Accessibility settings, and you can switch it off there at any time.
 */
public class PocketAccess extends AccessibilityService {

    static volatile PocketAccess instance;

    private final Handler h = new Handler(Looper.getMainLooper());
    private static final Pattern ON = Pattern.compile("\\bon\\b");
    private static final Pattern OFF = Pattern.compile("\\boff\\b");

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    boolean global(int action) {
        return performGlobalAction(action);
    }

    void say(String text) {
        try {
            Intent i = new Intent(this, ListenService.class)
                    .setAction(ListenService.ACTION_SAY)
                    .putExtra(ListenService.EXTRA_TEXT, text);
            startService(i);
        } catch (Exception e) {
            Intent b = new Intent(ListenService.ACTION_LOG).setPackage(getPackageName())
                    .putExtra(ListenService.EXTRA_TEXT, "Pocket: " + text);
            sendBroadcast(b);
        }
    }

    /** Reads the text that is visible on the current screen. */
    String readScreen() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "";
        StringBuilder sb = new StringBuilder();
        collect(root, sb, 0);
        return sb.toString().trim();
    }

    private void collect(AccessibilityNodeInfo n, StringBuilder sb, int depth) {
        if (n == null || sb.length() > 400 || depth > 25) return;
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        if (t != null && t.length() > 0) sb.append(t).append(". ");
        else if (d != null && d.length() > 0) sb.append(d).append(". ");
        for (int i = 0; i < n.getChildCount(); i++) {
            collect(n.getChild(i), sb, depth + 1);
        }
    }

    private AccessibilityNodeInfo find(AccessibilityNodeInfo root, String[] names) {
        for (String name : names) {
            List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(name);
            if (list != null && !list.isEmpty()) return list.get(0);
        }
        return null;
    }

    private boolean click(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        int guard = 0;
        while (n != null && guard < 8) {
            if (n.isClickable()) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            n = n.getParent();
            guard++;
        }
        return false;
    }

    /** Taps a button or label that has this text on the current screen. */
    boolean tapText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(text);
        if (list == null || list.isEmpty()) return false;
        return click(list.get(0));
    }

    boolean scroll(boolean forward) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo target = findScrollable(root, 0);
        if (target == null) return false;
        return target.performAction(forward
                ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
    }

    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 25) return null;
        if (n.isScrollable()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findScrollable(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    boolean typeText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f == null) return false;
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    /** Opens Quick Settings, finds the tile, taps it if it is not already in the wanted state, then closes. */
    void toggle(final String label, final String[] names, final Boolean wantOn) {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
        attempt(label, names, wantOn, 0);
    }

    private final Runnable closePanel = new Runnable() {
        @Override
        public void run() {
            performGlobalAction(GLOBAL_ACTION_BACK);
        }
    };

    private void attempt(final String label, final String[] names, final Boolean wantOn, final int tries) {
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                AccessibilityNodeInfo root = getRootInActiveWindow();
                AccessibilityNodeInfo node = root == null ? null : find(root, names);
                if (node != null) {
                    CharSequence cd = node.getContentDescription();
                    CharSequence tx = node.getText();
                    String d = ((cd == null ? "" : cd) + " " + (tx == null ? "" : tx)).toLowerCase(Locale.ROOT);
                    boolean on = ON.matcher(d).find();
                    boolean off = OFF.matcher(d).find();
                    if (wantOn != null && ((wantOn && on && !off) || (!wantOn && off && !on))) {
                        say(label + " is already " + (wantOn ? "on." : "off."));
                        h.postDelayed(closePanel, 400);
                        return;
                    }
                    boolean ok = click(node);
                    say(ok ? "Done. " + label + " switched." : "I could not tap the " + label + " tile.");
                    h.postDelayed(closePanel, 700);
                } else if (tries == 0) {
                    performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
                    attempt(label, names, wantOn, 1);
                } else {
                    say("I could not find the " + label + " tile in Quick Settings.");
                    h.postDelayed(closePanel, 400);
                }
            }
        }, 900);
    }
}
